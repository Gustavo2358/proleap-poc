from pathlib import Path
import json,subprocess,hashlib
r=Path('/home/gustavo/workspace/teste-e2e/proleap-poc');out=Path('/tmp/cp6-w1a-cli');out.mkdir(exist_ok=True)
m2=Path('/home/gustavo/.m2/repository')
jars=['org/antlr/antlr4-runtime/4.13.2/antlr4-runtime-4.13.2.jar','org/slf4j/slf4j-api/2.0.18/slf4j-api-2.0.18.jar','ch/qos/logback/logback-core/1.6.3/logback-core-1.6.3.jar','ch/qos/logback/logback-classic/1.6.3/logback-classic-1.6.3.jar','com/fasterxml/jackson/core/jackson-core/2.22.2/jackson-core-2.22.2.jar','com/fasterxml/jackson/core/jackson-databind/2.22.2/jackson-databind-2.22.2.jar','com/fasterxml/jackson/core/jackson-annotations/2.22/jackson-annotations-2.22.jar']
cp=':'.join([str(r/'target/classes')]+[str(m2/p) for p in jars]);result=[]
for label in ['dynamic-x8','literal']:
 raw=(r/'docs/work/evidence/WORK-AST-005/red'/f'{label}.cbl').read_text()
 # Make COBOL fixed source columns explicit, preserving the exact semantic fixture.
 f=out/f'{label}.cbl';f.write_text(''.join('       '+line+'\n' for line in raw.splitlines()))
 for run in [1,2]:
  dest=out/f'{label}-{run}'
  cmd=['/tmp/jcl-jdk21/bin/java','-cp',cp,'io.github.gustavo2358.cobolexplorer.ExplorerMain','--source',str(f),'--copybooks',str(r/'corpus/cpy'),'--output',str(dest)]
  p=subprocess.run(cmd,cwd=r,capture_output=True,text=True);(out/f'{label}-{run}.log').write_text(p.stdout+p.stderr);p.check_returncode()
  data=(dest/'cobol-semantic-product.json').read_bytes();assert json.loads(data)['contractVersion']=='1.3.0'
  result.append({'fixture':label,'run':run,'exit':p.returncode,'sha256':hashlib.sha256(data).hexdigest()})
 assert (out/f'{label}-1/cobol-semantic-product.json').read_bytes()==(out/f'{label}-2/cobol-semantic-product.json').read_bytes()
cmd=['/tmp/jcl-jdk21/bin/java','-cp',cp,'io.github.gustavo2358.cobolexplorer.ExplorerMain','--source',str(r/'src/test/resources/cobol/semantic/AIR-MOVE.cbl'),'--copybooks',str(r/'corpus/cpy'),'--output',str(out/'cp5')]
p=subprocess.run(cmd,cwd=r,capture_output=True,text=True);(out/'cp5.log').write_text(p.stdout+p.stderr);p.check_returncode()
old_bytes=subprocess.check_output(['git','-C',str(r.parent/'cobol-lower'),'show','18016f16b4f63149eb1bb4ca13db7e12593d8909:adapters/src/test/resources/sp/scalar-move-1.2.0.json'])
new_bytes=(out/'cp5/cobol-semantic-product.json').read_bytes();old=json.loads(old_bytes);new=json.loads(new_bytes)
assert old.pop('contractVersion')=='1.2.0' and new.pop('contractVersion')=='1.3.0'
for statement in new['statements']:
 if statement['variant']=='MOVE':assert statement.pop('textAdjustment') is None
assert old==new,'CP5 old facts drifted'
result.append({'fixture':'CP5 AIR-MOVE','exit':p.returncode,'oldSha256':hashlib.sha256(old_bytes).hexdigest(),'newSha256':hashlib.sha256(new_bytes).hexdigest(),'oldFactsEquivalent':True,'delta':['contractVersion 1.2.0 -> 1.3.0','MOVE.textAdjustment=null']})
(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
