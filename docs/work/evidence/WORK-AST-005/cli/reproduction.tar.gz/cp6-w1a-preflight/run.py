from pathlib import Path
import hashlib
import json
import subprocess

ROOT = Path(__file__).resolve().parent
REPO = Path('/home/gustavo/workspace/teste-e2e/cobol-lower')
SHA = '18016f16b4f63149eb1bb4ca13db7e12593d8909'
paths = ['core/src/main/java/io/github/gustavo2358/lower/domain/SpInput.java']
paths += ['adapters/src/main/java/io/github/gustavo2358/lower/adapters/sp/' + name
          for name in ['Wire.java', 'Wire12.java', 'Materialize.java', 'SpJsonDecoder.java']]
fixture = 'adapters/src/test/resources/sp/scalar-move-1.2.0.json'
manifest = {'repository': 'Gustavo2358/cobol-lower', 'commit': SHA, 'files': {}}
for relative in paths + [fixture]:
    data = subprocess.check_output(['git', '-C', str(REPO), 'show', SHA + ':' + relative])
    destination = ROOT / 'frozen-lower' / relative
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(data)
    manifest['files'][relative] = hashlib.sha256(data).hexdigest()
jars = [Path('/home/gustavo/.m2/repository/com/fasterxml/jackson/core') / relative for relative in [
    'jackson-core/2.22.2/jackson-core-2.22.2.jar',
    'jackson-databind/2.22.2/jackson-databind-2.22.2.jar',
    'jackson-annotations/2.22/jackson-annotations-2.22.jar']]
manifest['dependencies'] = {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in jars}
classpath = ':'.join(map(str, jars))
classes = ROOT / 'classes'
classes.mkdir(exist_ok=True)
commands = [
    ['/tmp/jcl-jdk21/bin/javac', '--release', '21', '-cp', classpath, '-d', str(classes)]
        + [str(ROOT / 'frozen-lower' / p) for p in paths] + [str(ROOT / 'CompatibilityProbe.java')],
    ['/tmp/jcl-jdk21/bin/java', '-cp', str(classes) + ':' + classpath, 'CompatibilityProbe',
        str(ROOT / 'frozen-lower' / fixture), str(ROOT / 'evidence')]]
for i, command in enumerate(commands):
    completed = subprocess.run(command, capture_output=True, text=True)
    (ROOT / 'evidence' / f'{i}-run.log').write_text(completed.stdout + completed.stderr)
    manifest.setdefault('commands', []).append({'argv': command, 'exit': completed.returncode})
    print(completed.stdout + completed.stderr, end='')
    (ROOT / 'evidence' / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    completed.check_returncode()
