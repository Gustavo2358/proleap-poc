import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import io.github.gustavo2358.lower.adapters.sp.SpJsonDecoder;
import java.nio.file.Files;
import java.nio.file.Path;

/** Diagnostic probe only. Compiles the frozen decoder; no product edits. */
public final class CompatibilityProbe {
    public static void main(String[] args) throws Exception {
        var json = new ObjectMapper();
        var input = Path.of(args[0]);
        var out = Path.of(args[1]);
        byte[] original = Files.readAllBytes(input);
        var baseline = (ObjectNode) json.readTree(original);
        check("baseline-1.2.0", original, null, out);
        var version = baseline.deepCopy();
        version.put("contractVersion", "1.3.0");
        check("version-only-1.3.0", json.writeValueAsBytes(version),
                SpJsonDecoder.Code.UNSUPPORTED_CONTRACT, out);
        var additive = baseline.deepCopy();
        ObjectNode move = null;
        for (var statement : additive.withArray("statements")) {
            if (statement.path("variant").asText().equals("MOVE")) {
                move = (ObjectNode) statement;
                break;
            }
        }
        if (move == null) throw new AssertionError("fixture requires a MOVE");
        move.putNull("valueSemantics");
        check("additive-move-field-under-1.2.0", json.writeValueAsBytes(additive),
                SpJsonDecoder.Code.INPUT_ERROR, out);
    }

    private static void check(String name, byte[] bytes, SpJsonDecoder.Code expected,
                              Path out) throws Exception {
        Files.write(out.resolve(name + ".json"), bytes);
        var result = new SpJsonDecoder(new SpJsonDecoder.Limits(64)).decode(bytes);
        if (expected == null) {
            if (!(result instanceof SpJsonDecoder.Decoded decoded))
                throw new AssertionError(name + " unexpectedly rejected: " + result);
            System.out.println(name + " => DECODED; statements=" + decoded.input().statements().size());
        } else {
            if (!(result instanceof SpJsonDecoder.Rejected rejected)
                    || rejected.diagnostic().code() != expected)
                throw new AssertionError(name + " wrong rejection: " + result);
            System.out.println(name + " => " + result);
        }
    }
}
