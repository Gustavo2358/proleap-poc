import java.nio.file.*;
import io.github.gustavo2358.lower.adapters.sp.SpJsonDecoder;
public class FrozenInputProbe {
  public static void main(String[] args) throws Exception {
    for (String input : args) {
      var result = new SpJsonDecoder(new SpJsonDecoder.Limits(64)).decode(Files.readAllBytes(Path.of(input)));
      System.out.println(Path.of(input).getParent().getFileName() + " => " + result);
      if (!(result instanceof SpJsonDecoder.Rejected r) || r.diagnostic().code() != SpJsonDecoder.Code.UNSUPPORTED_CONTRACT)
        throw new AssertionError("new SP version must be explicitly rejected by the frozen consumer");
    }
  }
}
