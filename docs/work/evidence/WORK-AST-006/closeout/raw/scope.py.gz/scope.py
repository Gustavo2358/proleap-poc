import subprocess,json,hashlib
from pathlib import Path
root=Path.cwd();out=root/'target/cp6-w2a-closeout';initial=json.loads((out/'local-preflight.json').read_text());merged=json.loads((out/'merged.json').read_text())
def git(repo,*args):return subprocess.check_output(['git','-C',str(repo),*args],text=True).strip()
for name,old in initial['repositories'].items():
 if name==root.name:continue
 p=root.parent/name;now={'head':git(p,'rev-parse','HEAD'),'tree':git(p,'rev-parse','HEAD^{tree}'),'branch':git(p,'branch','--show-current'),'status':git(p,'status','--porcelain=v1'),'branches':git(p,'branch','--format=%(refname:short)').splitlines()};assert old==now,(name,old,now)
for path,digest in initial['existingEvidenceSha256'].items():
 if path=='docs/work/evidence/WORK-AST-006/README.md':
  saved=Path('docs/work/evidence/WORK-AST-006/closeout/reviewed-handoff.md.txt').read_bytes()
  assert hashlib.sha256(saved).hexdigest()==digest
  assert Path(path).read_bytes()==saved.replace(b'../../active/WORK-AST-006/spec.md',b'../../history/WORK-AST-006.md')
 else:assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==digest,path
assert not git(root,'diff',merged['mergeSha'],'--','src','scripts','pom.xml','.github','ARCHITECTURE.md')
assert not git(root,'ls-files','--others','--exclude-standard','src','scripts','.github')
contract='docs/domain/if-semantic-product.md';old=subprocess.check_output(['git','show',merged['mergeSha']+':'+contract]).decode();assert Path(contract).read_text()==old.replace('../work/active/WORK-AST-006/spec.md','../work/history/WORK-AST-006.md')
allowed={'docs/work/evidence/WORK-AST-006/README.md','AGENTS.md','docs/index.md','docs/work/index.md',contract,'docs/work/history/WORK-AST-006.md'}
changed=set(git(root,'diff','--name-only',merged['mergeSha']).splitlines())|set(git(root,'ls-files','--others','--exclude-standard').splitlines())
assert all(p in allowed or p.startswith('docs/work/active/WORK-AST-006/') or p.startswith('docs/work/evidence/WORK-AST-006/closeout/') for p in changed),changed
for p in Path('docs/work/evidence/WORK-AST-006/closeout/work-item-reviewed').iterdir():
 name=p.name.removesuffix('.txt');assert p.read_bytes()==subprocess.check_output(['git','show',merged['sourceHead']+':docs/work/active/WORK-AST-006/'+name])
assert git(root,'branch','--show-current')=='main'
assert git(root,'branch','--format=%(refname:short)').splitlines()==initial['repositories'][root.name]['branches']
assert git(root,'rev-parse','feat/cp6-w2a-if-semantic-facts')==merged['sourceHead']
subprocess.run(['git','merge-base','--is-ancestor',merged['sourceHead'],'HEAD'],check=True)
subprocess.run(['git','diff','--check'],check=True)
r={'result':'PASS','mergeSha':merged['mergeSha'],'qualifiedTreePreservedAtMerge':True,'productionTestsHarnessUnchanged':True,'normativeIfContractOnlyArchiveLinkChanged':True,'oldEvidenceFilesBytePreserved':len(initial['existingEvidenceSha256'])-1,'evidenceReadmeOnlyArchiveLinkChanged':True,'originalEvidenceReadmeBytePreservedInArchive':True,'reviewedWorkItemFilesPreserved':5,'siblingsUnchanged':True,'branchInventoryUnchanged':True,'sourceBranchAtReviewedHead':True,'administrativePaths':sorted(changed)}
(out/'administrative-scope.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items() if k!='administrativePaths'},indent=2))
