import sys,subprocess,json,hashlib,time
from pathlib import Path
root=Path.cwd();out=root/'target/cp6-w2a-closeout';label=sys.argv[1];command=sys.argv[2:]
out.mkdir(exist_ok=True)
log=out/(label+'.log');receipt=out/(label+'.receipt.json');assert not log.exists() and not receipt.exists()
def git(*args):return subprocess.check_output(['git','-C',str(root),*args],text=True).strip()
head=git('rev-parse','HEAD');tree=git('rev-parse','HEAD^{tree}');start=time.time()
with log.open('xb') as stream:r=subprocess.run(command,stdout=stream,stderr=subprocess.STDOUT)
record={'command':command,'exitCode':r.returncode,'startedAtEpoch':start,'elapsedSeconds':round(time.time()-start,3),'headBefore':head,'treeBefore':tree,'headAfter':git('rev-parse','HEAD'),'treeAfter':git('rev-parse','HEAD^{tree}'),'logSha256':hashlib.sha256(log.read_bytes()).hexdigest()}
receipt.write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record));print(log.read_text()[-2000:] if r.returncode else '')
sys.exit(r.returncode)
