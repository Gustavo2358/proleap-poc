import subprocess,json,sys,hashlib
from pathlib import Path
out=Path('target/cp6-w2a-closeout');label=sys.argv[1];draft=sys.argv[2]=='draft'
initial=json.loads((out/'remote-preflight.json').read_text())
def api(path):return json.loads(subprocess.check_output(['gh','api','repos/Gustavo2358/proleap-poc/'+path],text=True))
p=api('pulls/35');checks=api('commits/a86be664bf099ab7d8b9fc02794369391702f000/check-runs')
r={'pr':p,'checks':checks,'reviews':api('pulls/35/reviews?per_page=100'),'reviewComments':api('pulls/35/comments?per_page=100'),'issueComments':api('issues/35/comments?per_page=100')}
(out/(label+'.json')).write_text(json.dumps(r,indent=2)+'\n')
assert p['head']['sha']=='a86be664bf099ab7d8b9fc02794369391702f000','REVIEWED_HEAD_LOST'
assert initial['head']['tree']['sha']=='5880e174b33c85ba3f3cdbc70bd2d8dc7b1d567b','REVIEWED_TREE_LOST'
assert p['base']['ref']=='main' and p['base']['sha']=='53d774026a1e4bcd969c7783a1d277aaa87b5f2f'
assert p['state']=='open' and not p['merged'] and p['auto_merge'] is None and p['draft']==draft
assert p['mergeable'] and p['mergeable_state']=='clean'
assert p['body']==initial['pr']['body'],'PR_BODY_CHANGED'
for k in ['reviews','reviewComments','issueComments']:assert r[k]==initial[k],k+' CHANGED'
assert checks['total_count']>0 and all(c['status']=='completed' and c['conclusion']=='success' for c in checks['check_runs'])
assert subprocess.check_output(['git','status','--porcelain=v1'],text=True).strip()==''
print(json.dumps({'result':'PASS','head':p['head']['sha'],'tree':initial['head']['tree']['sha'],'draft':p['draft'],'base':p['base']['ref'],'mergeable':p['mergeable'],'ci':'SUCCESS','newReviewsOrFindings':False,'autoMerge':p['auto_merge']}))
